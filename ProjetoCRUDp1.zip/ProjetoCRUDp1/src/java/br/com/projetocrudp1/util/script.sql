﻿CREATE TABLE aluno(
idAluno serial CONSTRAINT pk_aluno PRIMARY KEY NOT NULL,
nomeAluno varchar(200) NOT NULL,
raAluno int NOT NULL, 
cpfAluno varchar(14) NOT NULL);

CREATE TABLE disciplina(
idDisciplina serial CONSTRAINT pk_disciplina PRIMARY KEY NOT NULL,
nomeDisciplina varchar(200) NOT NULL,
cargaHoraria int NOT NULL, 
diaSemana varchar(200) NOT NULL);

create table professor(
idProfessor serial not null,
nomeProfessor varchar(50) not null,
rmProfessor int not null,
salarioProfessor numeric not null
);