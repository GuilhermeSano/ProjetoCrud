/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projetocrudp1.dao;


import br.com.projetocrudp1.model.Aluno;
import br.com.projetocrudp1.util.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;


public class AlunoDAO implements GenericDAO {
    
    //Abrindo conexão com o banco através da ConnectionFactory
    private Connection conn;
    
    //throws - Identifica que meu método vai tratar exceções
    public AlunoDAO() throws Exception {
        //try/catch serve para tratamento de exceção
        try {
            this.conn = ConnectionFactory.getConnection();
            //Mostra uma mensagem no Terminal
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override
    public Boolean cadastrar(Object object) {
        Aluno aluno = (Aluno) object;
        //PreparedStatement - representa uma instrução SQL
        PreparedStatement stmt = null;
        //Apagar a linha abaixo
        String sql = "INSERT INTO aluno (nomeAluno, raAluno, cpfAluno) VALUES (?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, aluno.getNomeAluno());
            stmt.setInt(2, aluno.getRaAluno());
            stmt.setString(3, aluno.getCpfAluno());
            stmt.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problemas ao Cadastrar Aluno! ERRO: " + ex.getMessage());
            //Mostra a pilha de erros:
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de Conexão! ERRO: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
}
