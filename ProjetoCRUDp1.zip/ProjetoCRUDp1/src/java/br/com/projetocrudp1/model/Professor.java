/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projetocrudp1.model;

public class Professor {

    private Integer idProfessor;
    private String nomeProfessor;
    private Integer rmProfessor;
    private Double salarioProfessor;

    public Professor() {

    }

    public Professor(Integer idProfessor, String nomeProfessor, Integer rmProfessor, Double salarioProfessor) {
        this.idProfessor = idProfessor;
        this.nomeProfessor = nomeProfessor;
        this.rmProfessor = rmProfessor;
        this.salarioProfessor = salarioProfessor;
    }

    public Integer getIdProfessor() {
        return idProfessor;
    }

    public void setIdProfessor(Integer idProfessor) {
        this.idProfessor = idProfessor;
    }

    public String getNomeProfessor() {
        return nomeProfessor;
    }

    public void setNomeProfessor(String nomeProfessor) {
        this.nomeProfessor = nomeProfessor;
    }

    public Integer getRmProfessor() {
        return rmProfessor;
    }

    public void setRmProfessor(Integer rmProfessor) {
        this.rmProfessor = rmProfessor;
    }

    public Double getSalarioProfessor() {
        return salarioProfessor;
    }

    public void setSalarioProfessor(Double salarioProfessor) {
        this.salarioProfessor = salarioProfessor;
    }

    public void setSalarioProfessor(String salarioProfessor) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
