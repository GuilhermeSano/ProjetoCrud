/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.projetocrudp1.model;

public class Aluno {
    //Criação dos Atributos
    private Integer idAluno;
    private String nomeAluno;
    private Integer raAluno;
    private String cpfAluno;
    
    //Criação dos métodos construtores

    public Aluno() {
    }

    public Aluno(Integer idAluno, String nomeAluno, Integer raAluno, String cpfAluno) {
        this.idAluno = idAluno;
        this.nomeAluno = nomeAluno;
        this.raAluno = raAluno;
        this.cpfAluno = cpfAluno;
    }
    
    //Criando os Getters e Setters
    //Get - Busca um valor
    //Set - Atribui um valor

    public Integer getIdAluno() {
        return idAluno;
    }

    public void setIdAluno(Integer idAluno) {
        this.idAluno = idAluno;
    }

    public String getNomeAluno() {
        return nomeAluno;
    }

    public void setNomeAluno(String nomeAluno) {
        this.nomeAluno = nomeAluno;
    }

    public Integer getRaAluno() {
        return raAluno;
    }

    public void setRaAluno(Integer raAluno) {
        this.raAluno = raAluno;
    }

    public String getCpfAluno() {
        return cpfAluno;
    }

    public void setCpfAluno(String cpfAluno) {
        this.cpfAluno = cpfAluno;
    }
    
    
}
